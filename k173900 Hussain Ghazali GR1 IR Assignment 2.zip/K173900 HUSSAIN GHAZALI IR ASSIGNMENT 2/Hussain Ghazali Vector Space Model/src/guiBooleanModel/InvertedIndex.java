
//HUSSAIN GHAZALI
//K17-3900
//SECTION-A

// THIS IS THE INVERTED INDEX FILE

package guiBooleanModel;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;


// INVERTED INDEX CLASS

public class InvertedIndex {
    public Map<String, ArrayList<Integer>> dictionary;
    
    public InvertedIndex ( ) {
        dictionary = new HashMap<>();
    }
    
    public InvertedIndex constructIndex ( BooleanModel bm, ArrayList<String> collection, Tokenizer t ) throws FileNotFoundException {
        ArrayList<String> stopword = bm.fetchStopword();
                        
        for ( int i=0; i<collection.size(); ++i ) {
            String temp = t.removeStopword(collection.get(i), stopword);
            String[] array = temp.split(" ");
            
            for ( int j=1; j<array.length; ++j ) {
                if ( !(this.dictionary.containsKey(array[j])) ) {
                    ArrayList<Integer> list = new ArrayList<>();
                    list.add(i+1);
                                    
                    this.dictionary.put(array[j], list);
                } else {
                    ArrayList<Integer> list = this.dictionary.get(array[j]);
                    list.add(i+1);
                                    
                    this.dictionary.put(array[j], list);
                }
            }
        }
        
        this.sortAndRemoveDuplicateHash();
        return this;
    }
    
    private ArrayList<Integer> removeDuplicate ( ArrayList<Integer> posting ) {
        ArrayList<Integer> removeDuplicate = new ArrayList<>();
        for ( int i=0; i<posting.size(); ++i ) {
            if( !removeDuplicate.contains(posting.get(i)) ) removeDuplicate.add(posting.get(i));
        }
        
        return removeDuplicate;
    }
    
    // CHECKING OF HASHING
    
    private void sortAndRemoveDuplicateHash ( ) {
        dictionary.entrySet().stream().map((entry) -> {
            entry.setValue(removeDuplicate(entry.getValue()));
            return entry;
        }).forEachOrdered((entry) -> {
            Collections.sort(entry.getValue());
        });
        
        Map<String, ArrayList<Integer>> map = new TreeMap<>(dictionary);
        dictionary = map;
    }
    
    // PRINTING OF INDEXES
    
    public void printIndex ( ) {
        dictionary.entrySet().stream().map((entry) -> {
            System.out.print(entry.getKey() + " " + entry.getValue().size() + " -> ");
            return entry;
        }).map((entry) -> {
            for ( int i=0; i<entry.getValue().size(); ++i ) System.out.print(entry.getValue().get(i) + " ");
            return entry;
        }).forEachOrdered((_item) -> {
            System.out.println();
        });
    }
    
    // WRITING INDEX ON FILES
    
    public void writeIndexToFile ( ) throws IOException {
        File file = new File("dataset/Inverted-Index.txt");
        
        if ( !file.exists() ) 
            file.createNewFile();
        
        FileWriter fw = new FileWriter(file);
        try (BufferedWriter bw = new BufferedWriter(fw)) {
            int j=0;
            for ( Map.Entry<String, ArrayList<Integer>> entry : dictionary.entrySet() ) {
                if ( j>=1 ) {
                    bw.write(entry.getKey() + " " + entry.getValue().size() + " -> ");
                    for ( int i=0; i<entry.getValue().size(); ++i ) bw.write(entry.getValue().get(i) + " ");
                    bw.newLine();
                } else ++j;
            }
            
            bw.flush();
        }
    }
    
    
    // OPENING THE FILE TO OUTPUT
    
    public void OpenFile ( ) throws IOException {
        File file = new File("dataset/Inverted-Index.txt");
        
        if ( Desktop.isDesktopSupported() ) {
            Desktop.getDesktop().edit(file);
        }
    }
}
